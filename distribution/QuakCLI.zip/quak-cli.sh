#!/bin/bash
java -jar ./QuakCLI-1.0-SNAPSHOT.jar "$@"
